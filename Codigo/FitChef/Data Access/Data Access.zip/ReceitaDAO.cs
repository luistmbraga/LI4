﻿using FitChef.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

namespace FitChef.Data_Access
{
    public class ReceitaDAO
    {
        private Connection _connection;

        public ReceitaDAO(Connection connection)
        {
            this._connection = connection;
        }

        public Receita FindById(int idR)
        {
            // Retornar a receita
            Receita obj = new Receita();

            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {

                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT id, nome, infNutricional FROM Receita WHERE id = @idR";

                command.Parameters.Add("@idR", SqlDbType.Int).Value = idR;

                command.Parameters.Add("@id", SqlDbType.Int).Value = obj.Id;
                command.Parameters.Add("@username", SqlDbType.VarChar).Value = obj.Nome;
                command.Parameters.Add("@pass", SqlDbType.Int).Value = obj.InfNutricional;

                command.ExecuteNonQuery();
            }
            return obj;
        }

        public bool Insert(Receita obj)
        {
            bool updated = false;
            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "INSERT INTO Receita VALUES(@nome, @infNutricional)";


                command.Parameters.Add("@username", SqlDbType.VarChar).Value = obj.Nome;
                command.Parameters.Add("@pass", SqlDbType.Int).Value = obj.InfNutricional;

                if (command.ExecuteNonQuery() > 0)
                {
                    updated = true;
                }
                return updated;
            }

        }

        public Collection<Receita> FindAll()
        {
            Collection<Receita> receitas = new Collection<Receita>();


            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT id, nome, infNutricional FROM Receita";

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable tab = new DataTable();
                    adapter.Fill(tab);

                    foreach (DataRow row in tab.Rows)
                    {
                        Receita rec = new Receita
                        {
                            Id = (int)row["id"],
                            Nome = row["nome"].ToString(),
                            InfNutricional = (int)row["infNutricional"]
                        };
                        receitas.Add(rec);
                    }
                }
                return receitas;
            }
        }

        public Collection<Passo> FindPassosFromReceita(int id)
        {
            Collection<Passo> resultado = new Collection<Passo>();

            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {

                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT p.id, p.descricao " + "FROM Receita_Passo_Ingrediente r, Passo p "
                                        + "WHERE r.Receita_id = @id and p.id = r.Passo_id ";

                command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable tab = new DataTable();
                    adapter.Fill(tab);
                    foreach (DataRow row in tab.Rows)
                    {
                        Passo p = new Passo
                        {
                            Id = (int)row["p.id"],
                            Descricao = row["p.descricao"].ToString()
                        };
                        resultado.Add(p);
                    }
                }
            }

            return resultado;
        }

        public Collection<Ingrediente> FindIngredientesFromReceita(int id)
        {
            Dictionary<int, Ingrediente> resultado = new Dictionary<int, Ingrediente>();

            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT i.id, i.nome, i.unidade, r.quantidade " + "FROM Receita_Passo_Ingrediente r, Ingrediente i " +
                                           "WHERE @id = r.Receita_id and r.Ingrediente_id = i.id";

                command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable tab = new DataTable();
                    adapter.Fill(tab);
                    foreach (DataRow row in tab.Rows)
                    {
                        Ingrediente ing = new Ingrediente
                        {
                            Id = (int)row["id"],
                            Nome = row["nome"].ToString(),
                            Unidade = row["unidade"].ToString(),
                            Quantidade = (int)row["quantidade"]
                        };

                        if(!resultado.ContainsKey(ing.Id)) resultado.Add(ing.Id, ing);
                        else
                        {
                            Ingrediente aux = resultado[ing.Id];
                            ing.Quantidade += aux.Quantidade;
                            resultado.Remove(ing.Id);
                            resultado.Add(ing.Id, ing);
                        }
                    }
                }

            }
            Collection<Ingrediente> r = new Collection<Ingrediente>();

            foreach(Ingrediente i in resultado.Values)
            {
                r.Add(i);
            }

            return r;
        }

        public Collection<Utensilio> FindUtensiliosFromReceita(int id)
        {
            Collection<Utensilio> resultado = new Collection<Utensilio>();

            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "Select u.id, u.nome " + "From receita_utensilio r, Utensilio u "
                                            + "Where u.id = r.Utensilio_id and r.Receita_id = @id;";

                command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable tab = new DataTable();
                    adapter.Fill(tab);
                    foreach (DataRow row in tab.Rows)
                    {
                        Utensilio u = new Utensilio
                        {
                            Id = (int)row["id"],
                            Nome = row["nome"].ToString()
                        };

                        resultado.Add(u);
                    }
                }
            }

            return resultado;
        }

        /**
         * VerificaReceita(String Receita)
         * 
         * Verifica de uma dada receita existe
         */
        public bool VerificaReceita(String receita)
        {
            Boolean existe = false;

            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {

                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT id FROM receita WHERE nome = @receita";

                command.Parameters.Add("@receita", SqlDbType.VarChar).Value = receita;

                if (command.ExecuteReader().HasRows)
                {
                    existe = true;
                }
            }
            return existe;
        }


        /**
         * Update
         * 
         * Faz update de uma receita.
         */
        public bool Update(Receita obj)
        {
            bool updated = false;
            using (SqlCommand command = _connection.Fetch().CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = "UPDATE Receita Set nome=@nome, infNutricional=@infNutricional WHERE id=@ID";

                //... SqlDbType.
                command.Parameters.Add("@nome", SqlDbType.VarChar).Value = obj.Nome;
                command.Parameters.Add("@ID", SqlDbType.Int).Value = obj.Id;
                command.Parameters.Add("@infNutricional", SqlDbType.Int).Value = obj.InfNutricional;

                if (command.ExecuteNonQuery() > 0)
                {
                    updated = true;
                }
                return updated;
            }
        }


    }
}